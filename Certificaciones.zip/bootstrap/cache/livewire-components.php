<?php return array (
  'inicio-live' => 'App\\Http\\Livewire\\InicioLive',
);