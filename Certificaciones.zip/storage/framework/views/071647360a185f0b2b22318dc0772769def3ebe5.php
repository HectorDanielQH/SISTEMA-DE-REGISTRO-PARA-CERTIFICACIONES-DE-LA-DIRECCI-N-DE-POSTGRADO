<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="antialiased">
        <nav class="navbar navbar-expand-lg bg-light">
            <div class="container-fluid">
              <a class="navbar-brand" href="<?php echo e(route('registro.index')); ?>">CERTIFICACIONES - REGISTRO DE FOLDERS</a>
            </div>
        </nav>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('inicio-live')->html();
} elseif ($_instance->childHasBeenRendered('CZfo1cr')) {
    $componentId = $_instance->getRenderedChildComponentId('CZfo1cr');
    $componentTag = $_instance->getRenderedChildComponentTagName('CZfo1cr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CZfo1cr');
} else {
    $response = \Livewire\Livewire::mount('inicio-live');
    $html = $response->html();
    $_instance->logRenderedChild('CZfo1cr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
        <?php echo \Livewire\Livewire::scripts(); ?>        
    </body>
</html><?php /**PATH C:\laragon\www\Certificaciones\resources\views/registro/index.blade.php ENDPATH**/ ?>